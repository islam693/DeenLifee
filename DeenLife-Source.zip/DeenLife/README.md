# DeenLife — Android project

Native Android starter application built with Kotlin, Jetpack Compose, Room and Android notification channels.

## Open and run
1. Install Android Studio (recent stable version) and Android SDK 35.
2. Open this folder (`DeenLife`) in Android Studio.
3. Allow Gradle sync to download dependencies.
4. Run the `app` configuration on an Android 8.0+ device or emulator.

## Implemented in this first build
- Dark mobile UI with five navigation sections.
- Local persistent Room database for events, habits and prayer completion records.
- Daily home screen with today's events and completion progress.
- Date navigation and event creation/editable completion/deletion (event creation, completion and deletion are active).
- Study section based on event categories.
- Prayer completion tracker for five daily prayers.
- Android notification channel and Android 13+ permission request.

## Not yet implemented
This is a functional foundation, not the complete feature list from the brief. In particular, automated prayer-time calculations, Tahajjud night-third calculation, recurring events, scheduled per-event alarms, boot/time-zone rescheduling, sleep/habit trackers UI, analytics, drag-and-drop calendar, weather, cloud sync, import/export and backup are not included yet. The Islam screen intentionally does not invent prayer times: it asks for a city/method before a calculation engine is added.

## Technical notes
- Minimum SDK: 26 (Android 8.0)
- Target SDK: 35
- Database: `deenlife.db`
- All core event and prayer log data is local; internet is not required.
