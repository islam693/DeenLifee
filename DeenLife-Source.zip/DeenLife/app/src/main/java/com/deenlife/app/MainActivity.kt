package com.deenlife.app

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.room.Room
import com.deenlife.app.data.*
import com.deenlife.app.notifications.Notifications
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter

private val bg = Color(0xFF101816)
private val card = Color(0xFF1B2723)
private val mint = Color(0xFF75C6A5)

class MainActivity : ComponentActivity() {
    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Notifications.createChannel(this)
        if (Build.VERSION.SDK_INT >= 33) permission.launch(Manifest.permission.POST_NOTIFICATIONS)
        val dao = DeenDatabase.get(this).dao()
        setContent { DeenLifeApp(dao) }
    }
}

@Composable fun DeenLifeApp(dao: DeenDao) {
    var tab by remember { mutableStateOf(0) }
    val tabs = listOf("Главная", "Календарь", "Учёба", "Ислам", "Профиль")
    val icons = listOf(Icons.Default.Home, Icons.Default.CalendarMonth, Icons.Default.School, Icons.Default.Favorite, Icons.Default.Person)
    MaterialTheme(colorScheme = darkColorScheme(primary = mint, background = bg, surface = card)) {
        Scaffold(containerColor = bg, bottomBar = {
            NavigationBar(containerColor = card) {
                tabs.forEachIndexed { i, label -> NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(icons[i], null) }, label = { Text(label, fontSize = 10.sp) }) }
            }
        }) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                when (tab) {
                    0 -> HomeScreen(dao)
                    1 -> CalendarScreen(dao)
                    2 -> StudyScreen(dao)
                    3 -> IslamScreen(dao)
                    else -> ProfileScreen()
                }
            }
        }
    }
}

@Composable private fun Page(title: String, subtitle: String? = null, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(title, color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        if (subtitle != null) Text(subtitle, color = Color.LightGray, fontSize = 14.sp)
        content()
    }
}

@Composable private fun Panel(content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
    }
}

@Composable private fun HomeScreen(dao: DeenDao) {
    val today = LocalDate.now().toString()
    val events by dao.eventsForDay(today).collectAsState(initial = emptyList())
    val completed = events.count { it.done }
    Page("Мой день", LocalDate.now().format(DateTimeFormatter.ofPattern("d MMMM, EEEE"))) {
        Panel {
            Text("Ассаляму алейкум!", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
            Text(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm")), color = mint, fontSize = 34.sp, fontWeight = FontWeight.Bold)
            Text("Планируй спокойно. Двигайся последовательно.", color = Color.LightGray)
        }
        Panel {
            Text("Прогресс дня", color = Color.White, fontWeight = FontWeight.SemiBold)
            LinearProgressIndicator(progress = { if (events.isEmpty()) 0f else completed.toFloat() / events.size }, modifier = Modifier.fillMaxWidth(), color = mint)
            Text("$completed из ${events.size} задач выполнено", color = Color.LightGray)
        }
        Text("Расписание на сегодня", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        if (events.isEmpty()) Panel { Text("Пока нет задач. Добавь первое событие в календаре.", color = Color.LightGray) }
        events.forEach { EventRow(it, dao) }
    }
}

@Composable private fun EventRow(event: PlanEvent, dao: DeenDao) {
    val scope = rememberCoroutineScope()
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.weight(1f)) {
                Text(event.title, color = Color.White, fontWeight = FontWeight.SemiBold)
                Text("${clock(event.startMinutes)} — ${clock(event.endMinutes)} · ${event.category}", color = Color.LightGray, fontSize = 12.sp)
                if (event.notes.isNotBlank()) Text(event.notes, color = Color.Gray, fontSize = 12.sp)
            }
            Checkbox(checked = event.done, onCheckedChange = { scope.launch { dao.updateEvent(event.copy(done = it)) } })
            IconButton(onClick = { scope.launch { dao.deleteEvent(event) } }) { Icon(Icons.Default.Delete, null, tint = Color.Gray) }
        }
    }
}

@Composable private fun CalendarScreen(dao: DeenDao) {
    var date by remember { mutableStateOf(LocalDate.now()) }
    val events by dao.eventsForDay(date.toString()).collectAsState(initial = emptyList())
    var showAdd by remember { mutableStateOf(false) }
    Page("Календарь", "Планируй день и добавляй события") {
        Panel {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { date = date.minusDays(1) }) { Icon(Icons.Default.ChevronLeft, null, tint = Color.White) }
                Text(date.format(DateTimeFormatter.ofPattern("d MMMM yyyy")), color = Color.White, fontWeight = FontWeight.Bold)
                IconButton(onClick = { date = date.plusDays(1) }) { Icon(Icons.Default.ChevronRight, null, tint = Color.White) }
            }
            Button(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Text("Добавить событие") }
        }
        events.forEach { EventRow(it, dao) }
        if (events.isEmpty()) Text("На эту дату событий нет.", color = Color.LightGray)
    }
    if (showAdd) AddEventDialog(date, dao) { showAdd = false }
}

@Composable private fun AddEventDialog(date: LocalDate, dao: DeenDao, close: () -> Unit) {
    var title by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Личное") }
    var start by remember { mutableStateOf("09:00") }
    var end by remember { mutableStateOf("10:00") }
    var notes by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    AlertDialog(onDismissRequest = close, title = { Text("Новое событие") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(title, { title = it }, label = { Text("Название") }, singleLine = true)
            OutlinedTextField(category, { category = it }, label = { Text("Категория") }, singleLine = true)
            OutlinedTextField(start, { start = it }, label = { Text("Начало (ЧЧ:ММ)") }, singleLine = true)
            OutlinedTextField(end, { end = it }, label = { Text("Конец (ЧЧ:ММ)") }, singleLine = true)
            OutlinedTextField(notes, { notes = it }, label = { Text("Заметки") })
            if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
        }
    }, confirmButton = { TextButton(onClick = {
        val s = parseClock(start); val e = parseClock(end)
        if (title.isBlank()) error = "Введи название"
        else if (s == null || e == null || e <= s) error = "Проверь время: формат ЧЧ:ММ, конец позже начала"
        else { scope.launch { dao.insertEvent(PlanEvent(title = title.trim(), category = category, date = date.toString(), startMinutes = s, endMinutes = e, notes = notes)) }; close() }
    }) { Text("Сохранить") } }, dismissButton = { TextButton(onClick = close) { Text("Отмена") } })
}

@Composable private fun StudyScreen(dao: DeenDao) {
    val events by dao.allEvents().collectAsState(initial = emptyList())
    val study = events.filter { it.category.equals("Учёба", true) || it.category.equals("Пара", true) }
    Page("Учёба", "Занятия, подготовка и дедлайны") {
        Panel {
            Text("Учебные события", color = Color.White, fontWeight = FontWeight.Bold)
            Text("Всего запланировано: ${study.size}", color = mint, fontSize = 25.sp)
            Text("Добавляй пары и самостоятельную подготовку через календарь, используя категорию «Учёба».", color = Color.LightGray)
        }
        study.sortedBy { it.date }.take(20).forEach { EventRow(it, dao) }
        if (study.isEmpty()) Text("Пока нет учебных событий.", color = Color.LightGray)
    }
}

@Composable private fun IslamScreen(dao: DeenDao) {
    val today = LocalDate.now().toString()
    val logs by dao.prayersForDate(today).collectAsState(initial = emptyList())
    val prayers = listOf("Фаджр", "Зухр", "Аср", "Магриб", "Иша")
    val scope = rememberCoroutineScope()
    var city by remember { mutableStateOf("Торонто") }
    Page("Ислам", "Намаз, поклонение и личные цели") {
        Panel {
            Text("Отметки намаза · $today", color = Color.White, fontWeight = FontWeight.Bold)
            Text("Времена намаза пока не рассчитаны: выбери город и метод расчёта в настройках исламского раздела.", color = Color.LightGray, fontSize = 12.sp)
            prayers.forEach { prayer ->
                val checked = logs.firstOrNull { it.prayer == prayer }?.completed == true
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(prayer, color = Color.White, modifier = Modifier.weight(1f))
                    Checkbox(checked = checked, onCheckedChange = { scope.launch { dao.savePrayer(PrayerLog(today, prayer, it)) } })
                }
            }
            Text("Выполнено: ${logs.count { it.completed }} / 5", color = mint)
        }
        Panel {
            Text("Трекер поклонения", color = Color.White, fontWeight = FontWeight.Bold)
            Text("Тахаджуд · Коран · Зикр · Пост · Джума", color = mint)
            Text("Раздел для ежедневных отметок. Автоматический расчёт молитвенных времён и календарь хиджры будут добавлены в следующей версии.", color = Color.LightGray)
        }
    }
}

@Composable private fun ProfileScreen() {
    Page("Профиль и настройки", "Персонализация DeenLife") {
        Panel {
            Text("Внешний вид", color = Color.White, fontWeight = FontWeight.Bold)
            Text("Тёмная тема активна", color = mint)
            Text("Интерфейс оптимизирован для смартфонов.", color = Color.LightGray)
        }
        Panel {
            Text("Уведомления", color = Color.White, fontWeight = FontWeight.Bold)
            Text("Разрешение Android на уведомления запрашивается при первом запуске. В этой версии системные уведомления доступны, а планировщик напоминаний для каждого события ещё не подключён.", color = Color.LightGray)
        }
        Panel {
            Text("Данные", color = Color.White, fontWeight = FontWeight.Bold)
            Text("Задачи, привычки и отметки намаза хранятся локально в Room Database.", color = Color.LightGray)
            Text("DeenLife · версия 1.0.0", color = mint)
        }
    }
}

private fun parseClock(value: String): Int? = try {
    val t = LocalTime.parse(value, DateTimeFormatter.ofPattern("H:mm")); t.hour * 60 + t.minute
} catch (_: Exception) { null }
private fun clock(minutes: Int): String = "%02d:%02d".format(minutes / 60, minutes % 60)
