package com.deenlife.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "events")
data class PlanEvent(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val category: String = "Личное",
    val date: String,
    val startMinutes: Int,
    val endMinutes: Int,
    val notes: String = "",
    val done: Boolean = false,
    val reminderMinutes: Int = 10
)

@Entity(tableName = "habits")
data class Habit(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val targetPerWeek: Int = 7,
    val completedDates: String = ""
)

@Entity(tableName = "prayer_log", primaryKeys = ["date", "prayer"])
data class PrayerLog(val date: String, val prayer: String, val completed: Boolean)

@Dao
interface DeenDao {
    @Query("SELECT * FROM events WHERE date = :date ORDER BY startMinutes") fun eventsForDay(date: String): Flow<List<PlanEvent>>
    @Query("SELECT * FROM events ORDER BY date, startMinutes") fun allEvents(): Flow<List<PlanEvent>>
    @Insert suspend fun insertEvent(event: PlanEvent): Long
    @Update suspend fun updateEvent(event: PlanEvent)
    @Delete suspend fun deleteEvent(event: PlanEvent)
    @Query("SELECT * FROM habits ORDER BY id") fun habits(): Flow<List<Habit>>
    @Insert suspend fun insertHabit(habit: Habit): Long
    @Update suspend fun updateHabit(habit: Habit)
    @Delete suspend fun deleteHabit(habit: Habit)
    @Query("SELECT * FROM prayer_log WHERE date = :date") fun prayersForDate(date: String): Flow<List<PrayerLog>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun savePrayer(log: PrayerLog)
}

@Database(entities = [PlanEvent::class, Habit::class, PrayerLog::class], version = 1, exportSchema = false)
abstract class DeenDatabase : RoomDatabase() {
    abstract fun dao(): DeenDao
    companion object {
        @Volatile private var INSTANCE: DeenDatabase? = null
        fun get(context: android.content.Context): DeenDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, DeenDatabase::class.java, "deenlife.db").build().also { INSTANCE = it }
        }
    }
}
